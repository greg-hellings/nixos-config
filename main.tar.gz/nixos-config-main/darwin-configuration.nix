{ ... }:

{
  imports = [
    ./modules
    ./hosts/work
  ];
}
