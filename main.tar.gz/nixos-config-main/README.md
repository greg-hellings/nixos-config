This is a unified repo to contain my personal configurations for NixOS machines.

# How To Use This

Go through the normal process to setup a NixOS system during installation.

1. Boot from an appropriate medium
2. Parition the drives
3. Mount them
4. Before you generate out the configuration, clone this repoistory to your
   /etc/nixos folder
5. Run the configuration generator. It should only genreate the hardware-configuration.nix
   file, which this repo gitignores
6. Create a folder and file with the machine name in `hosts/<machine>/default.nix`
7. Add `hosts/default.nix` an appropriate entry for the machine you are building
8. Create a file `home/hosts/<machine>/default.nix` with the new machine name as well

# Adding new hosts

To add a new host, create a folder in the directory `hosts/` that matches the name of
the target system. Each host must contain, minimally, a `default.nix` file that serves
as the basis of configuring that host.

# Test build a VM for your system

* `nom build ".#nixosConfigurations.<host>.config.system.build.vm`
* `export QEMU_NET_OPTS="hostfwd=tcp::2221-:22"` to export the SSH port
* `./result/bin/run-<host>-vm`
