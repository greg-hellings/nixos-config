{
  config,
  lib,
  nixvim,
  pkgs,
  ...
}:

{
  # The Hack font is used in the Fugitive sidebars
  fonts.fontconfig.enable = true;
  home.packages = with pkgs.nerd-fonts; [ hack ];

  programs.nixvim =
    (import ./config.nix {
      inherit
        config
        nixvim
        pkgs
        lib
        ;
    })
    // {
      enable = true;
    };
}
