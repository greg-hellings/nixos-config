{
  config,
  pkgs,
  metadata,
  ...
}:
let
  lan = "enp1s0";
  lanIP = metadata.hosts.${config.networking.hostName}.ip;
  iot = "enp2s0";
  iotIP = "192.168.66.250";
  #routerIP = metadata.infra.gw;
  extraHosts = builtins.readFile ./net/hosts;

  proxyPort = 3128;
  dnsPort = 53;
  dhcpPort = 67;
  dnsServers = [
    #"9.9.9.9" # Quad 9
    #"1.1.1.1" # Cloudflare
    #"1.0.0.1" # Cloudflare
    #"149.112.112.112" # Quad 9
    metadata.infra.gw # Currently using our UniFi router for DNS as well
  ];
in
{
  greg.tailscale = {
    enable = true;
    tags = [ "home" ];
  };

  # Really, why do I still have to force-disable this crap?
  boot.kernel.sysctl = {
    "net.ipv6.conf.${lan}.disable_ipv6" = true;
    "net.ipv6.conf.${iot}.disable_ipv6" = true;
    "net.ipv6.conf.lo.disable_ipv6" = true;
  };

  networking = {
    defaultGateway = metadata.infra.gw;
    enableIPv6 = false;
    networkmanager.enable = pkgs.lib.mkForce false;
    nameservers = dnsServers;
    interfaces = {
      # This is our LAN port
      "${lan}" = {
        useDHCP = false;
        ipv4.addresses = [
          {
            address = "${lanIP}";
            prefixLength = 16;
          }
        ];
      };

      "${iot}" = {
        useDHCP = false;
        ipv4.addresses = [
          {
            address = "${iotIP}";
            prefixLength = 24;
          }
        ];
      };
    };
    firewall = {
      enable = false;
      allowedUDPPorts = [
        dhcpPort
        dnsPort
      ];
      allowedTCPPorts = [
        dnsPort
        proxyPort
        80
      ];
    };
    nftables.enable = false;
  };

  environment.etc."hosts.d/local".text = extraHosts;

  services = {
    #########
    # dnsmasq config
    ########
    dnsmasq = {
      enable = true;
      settings = {
        domain = "thehellings.lan";
        expand-hosts = true;
        log-queries = true;
        no-hosts = true; # Do not read /etc/hosts, which makes genesis resolve to 127.0.0.2
        addn-hosts = "/etc/adblock_hosts";
        hostsdir = "/etc/hosts.d/";
        server = dnsServers;
      };
    };

    prometheus.exporters = {
      dnsmasq.enable = true;
      blackbox = {
        enable = true;
        openFirewall = true;
        configFile = pkgs.writeText "blackbox.yml" ''
          modules:
            icmp:
              prober: icmp
              timeout: 5s
              icmp:
                preferred_ip_protocol: ip4
        '';
      };
    };
  }; # End of services configuration

  environment.systemPackages = with pkgs; [
    bind
    curl # Used by dnsmasq fetching
    sqlite
  ];
}
