{
  config,
  metadata,
  pkgs,
  top,
  ...
}:

let
  ip = metadata.hosts.${config.networking.hostName}.ip;
  mk = file: {
    inherit file;
    owner = "buildbot";
    group = "buildbot";
  };
in
{
  imports = [
    ./hardware-configuration.nix
    top.buildbot.nixosModules.buildbot-master
    top.buildbot.nixosModules.buildbot-worker
  ];

  age.secrets = {
    runner-reg.file = ../../../secrets/gitlab/nixos-qemu-shell.age;

    gitea-buildbotWorkersFile = mk ../../../secrets/gitea/buildbotWorkersFile.age;
    gitea-oauthToken = mk ../../../secrets/gitea/oauthToken.age;
    gitea-oauthSecret = mk ../../../secrets/gitea/oauthSecret.age;
    gitea-webhookSecret = mk ../../../secrets/gitea/webhookSecret.age;
    gitea-workerPassword = mk ../../../secrets/gitea/workerPassword.age;
  };

  # Bootloader.
  boot = {
    initrd.kernelModules = [
      "amdgpu"
    ];
    kernelParams = [
    ];
    loader = {
      systemd-boot.enable = true;
      efi.canTouchEfiVariables = true;
    };
  };

  environment.systemPackages = with pkgs; [
    amdgpu_top
    clinfo
    curl
    gawk
    git
    mesa-demos
    unzip
    wget
  ];

  fileSystems = {
    "/nix" = {
      fsType = "btrfs";
      options = [ "subvol=nix" ];
      device = "/dev/nvme0n1p1";
    };
    "/var" = {
      fsType = "btrfs";
      options = [ "subvol=var" ];
      device = "/dev/nvme0n1p1";
    };
    "/var/pve" = {
      fsType = "btrfs";
      options = [ "subvol=pve" ];
      device = "/dev/nvme0n1p1";
    };
    "/btrfs" = {
      fsType = "btrfs";
      device = "/dev/nvme0n1p1";
    };
  };

  greg = {
    gitea-runner = {
      enable = true;
      extraLabels = [ "bare-metal:host" ];
    };
    home = true;
    kubernetes = {
      enable = true;
      vipInterface = "br0";
      vip = ip;
      priority = 254;
    };
    nebula.enable = true;
    tailscale = {
      enable = true;
      tags = [ "home" ];
    };
    remote-builder.enable = true;
    runner = {
      enable = true;
      threads = 3;
      qemu = true;
    };
  };

  hardware = {
    graphics = {
      enable = true;
      enable32Bit = true;
    };
  };

  networking = {
    hostName = "jeremiah"; # Define your hostname.
    useDHCP = false;
    bridges.br0 = {
      interfaces = [ "enp68s0" ];
    };
    defaultGateway = {
      address = metadata.infra.gw;
      interface = "br0";
    };
    firewall.allowedTCPPorts = [
      8010
      3389
      9989 # buildbot communications port
    ];
    interfaces.br0.ipv4 = {
      addresses = [
        {
          address = ip;
          prefixLength = 16;
        }
      ];
    };
    nameservers = [ metadata.infra.dns ];
  };

  services = {
    buildbot-nix = {
      master = {
        enable = true;
        admins = [ "greg" ];
        authBackend = "gitea";
        # Optional to build non-default branches at a time
        branches = {
          default = {
            matchGlob = "ma*";
            registerGCRoots = false;
            updateOutputs = false;
          };
        };
        domain = "${config.networking.hostName}.shire-zebra.ts.net";
        evalMaxMemorySize = 8192;
        evalWorkerCount = 4;
        gitea = {
          enable = true;
          instanceUrl = "https://src.thehellings.com";
          oauthId = "7ec9107d-379b-47c8-870f-1191956d0500";
          oauthSecretFile = config.age.secrets.gitea-oauthSecret.path;
          tokenFile = config.age.secrets.gitea-oauthToken.path;
          topic = "buildbot-nix";
          webhookSecretFile = config.age.secrets.gitea-webhookSecret.path;
        };
        showTrace = true;
        #webhookBaseUrl = "http://${config.networking.hostName}.shire-zebra.ts.net:8010";
        workersFile = config.age.secrets.gitea-buildbotWorkersFile.path;
      };
      worker = {
        enable = true;
        workerPasswordFile = config.age.secrets.gitea-workerPassword.path;
      };
    };
  };
}
