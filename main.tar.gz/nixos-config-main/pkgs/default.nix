{
  pkgs,
  system ? pkgs.stdenv.hostPlatform.system,
  ...
}:

let
  c = pkgs.callPackage;
in
{
  #default = iso;
  #iso = top.self.nixosConfigurations.iso.config.system.build.isoImage;
  #iso-beta = self.nixosConfigurations.iso-beta.config.system.build.isoImage;
  aacs = c ./aacs.nix { };
  brew = c ./homebrew.nix { };
  create_ssl = c ./create_ssl.nix { };
  gcc-tune = c ./gcc-tune.nix { };
  #gen-build = c ./gen-build { };
  hms = c ./hms { };
  inject-darwin = c ./inject-darwin.nix { };
  inject = c ./inject.nix { };
  setup-ssh = c ./setup-ssh { };
  upgrade-pg-cluster = c ./upgrade-pg-cluster.nix { };
}
// (
  if system == "x86_64-linux" then
    {
      qemu-hook = c ./qemu-hook.nix { };
      vfio_startup = c ./vfio_startup.nix { };
      vfio_shutdown = c ./vfio_shutdown.nix { };
      zim = c ./zim.nix { };
    }
  else
    { }
)
